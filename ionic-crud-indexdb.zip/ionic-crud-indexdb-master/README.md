# ionic-curd-indexdb
