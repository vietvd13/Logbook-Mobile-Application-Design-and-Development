# RingBell

Create a Ionic or any other similar platform utilizing the Notification API 
Create a Ionic that shows a confirmation dialog box to prompt users to push one button to ring a bell, and another button for vibrate.
