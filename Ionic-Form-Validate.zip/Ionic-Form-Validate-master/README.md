# Ionic-Form-Validate
Create a PhoneGap App that displays a form that allows a user to enter all the fields specified in the coursework section 1 a). The app should perform some validation of the data input and display an error message to the user if the data is invalid.

•	Property type (e.g. flat, house, bungalow) – required field
•	Bedrooms (e.g. studio, one, two, etc.) - required field
•	Date and time of adding the Property  (when the property have been added) – required field
•	Monthly rent price - required field
•	Furniture types (e.g. Furnished, Unfurnished, Part Furnished) - optional field
•	Notes – optional field
•	Name of the reporter – required fields

